import webview
import tkinter as tk
from tkinter import messagebox


webview.create_window("desktop.chatgpt")
webview.start()


startUp = print("started")
if startUp:
    print("started")
else:
    print("error")

